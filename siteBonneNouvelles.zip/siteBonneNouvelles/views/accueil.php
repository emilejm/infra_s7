		<section id="contenu">
			<h2>Accueil</h2>
			<p>Bienvenue aux séances d'exercices consacrées à élaborer un site Internet en PHP selon une architecture didactique MVC OO.</p>
			<p>Jean-Luc Collinet.</p>
		</section>